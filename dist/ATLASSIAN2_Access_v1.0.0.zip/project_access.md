## 1. 프로젝트 개요
이 프로젝트는 사용자의 요청에 따라 Atlassian 제품군(Confluence, Jira 등)의 접근을 위한 프로젝트입니다.

## 2. 프로젝트 목표
- 사용자의 요청에 따라 Jira 및 Confluence 접속하여 요청한 페이지를 오픈한다. 
- 사용자의 요청에 따라 Confluence 페이지에 내용을 추가하거나, 파일을 업로드한다.
- 사용자의 요청에 따라 Jira 이슈를 생성하거나, 수정한다.

## 3. SW stack
- Python 3.13
- Flask 3.1.0
- extract-msg 0.55.0
- SQLite
- HTML/CSS
- Windows Batch
- OpenAI API
- Atlassian API
- node.js
- npm

## 4. 디렉터리 및 파일 구조
- root
  └ Data 폴더 : RQMT파일을 저장 및 업로드를 위해 사용하는 폴더
- main.py
- frontend.py
- backend.py
- requirements.txt
- Run_app.bat
- .env
- ignore.env
- .tmp
- .venv


## 5. Frontend 형식
- HTML/CSS로 구현
- Flask를 사용하여 웹 애플리케이션으로 실행
- 애플의 제품설명 홈페이지 스타일을 참고하여 GUI를 구성한다.
- GUI는 다음과 같이 사이드바와 메인화면으로 구성된다.
- 사이드바에는 다음과 같은 항목이 있다.
  - 프로젝트 이름 입력창과 **Confluence 페이지 검색** 버튼
  - 프로젝트 이름 입력창과 **Jira 이슈 검색** 버튼
  
- 메인화면에는 다음과 같은 항목이 있다.
  - **Confluence 페이지 검색** 내용 결과창
    - **Confluence 페이지 검색** 버튼 클릭의 결과를 표시한다.
    - 해당 프로젝트의 **하위 트리구조를 모두 표시**한다.
    - 표시된 하위트리구조의 각 폴더를 클릭하면 해당 해당 Confluence 페이지를 브라우저에서 오픈한다.   
  - **Jira 이슈 검색** 내용 결과창
    - **Jira 이슈 검색** 버튼 클릭의 결과를 표시한다.
    - 해당 프로젝트의 **Jira 이슈 목록을 모두 표시**한다.
    - 표시된 Jira 이슈 목록의 각 이슈를 클릭하면 해당 해당 Jira WBS 페이지를 브라우저에서 오픈한다.
  

## 6. 참고 자료
- [ATLASSIAN2 구조 문서](../ATLASSIAN2/structure.md)
- [ATLASSIAN2 아키텍처 문서](../ATLASSIAN2/architecture.md)

## 7. 추가 사항
- 추가 내용은 직전 개선확인 이후 새롭게 변경된 사항만을 이 파일에 반영한다.
- 추가 기록에는 반드시 버전과 날짜를 함께 표시한다.
- 버전 표기는 예시와 같이 관리한다.
  - `v1.0.0 - 2026-03-24`
- 개선확인으로 추가되는 내용은 누적 기록 방식으로 관리한다.
- "Run_app.bat" 파일을 실행하여 애플리케이션을 실행한다.
- **추가개선**라고 프롬프트에 쓰면, 현재 기준 추가 개선된 부분을 정리하여 이 파일에 추가한다. 
